<?PHP
    $YourName=$_POST['YourName'];
     $YourEmail=$_POST['YourEmail'];
     $YourDate&Time=$_POST['YourDate&Time'];
      $YourText=$_POST['YourText'];

//Database connection 

?>